Tämän latauksen tietosivu ja viittausohjeet: http://tun.fi/HBF.53254

Lataus on tehty 8.6.2021 seuraavilla rajauksilla:
Lajin uhanalaisuusluokitus: VU – Vaarantuneet
Aika: 1990-01-01/2021-06-08
Lataus tietovarastoon, päivänä tai ennen: 2021-06-08
Koordinaatit: 60.392561 - 60.408755 N 22.446079 - 22.481938 E WGS84 vaadittu 
päällekkäisyyssuhde 1.0 
Koordinaattien tarkkuus: 100
Linkki hakuun: 
https://laji.fi/fi/observation/list?redListStatusId=MX.iucnVU&time=1990-01-01%2F2021-06-08&loadedSameOrBefore=2021-06-08&coordinates=60.392561%3A60.408755%3A22.446079%3A22.481938%3AWGS84%3A1.0&coordinateAccuracyMax=100 

Lataus koostuu seuraavista aineistoista joille on määritelty 
käyttöoikeuslisenssi: 

Hatikka.fi:n havainnot - http://tun.fi/HR.447
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Hyönteistietokanta - http://tun.fi/HR.200
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

LajiGIS: Lajin seurantakohteet - http://tun.fi/HR.3553
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa kaisa.junninen@metsa.fi; 
mira.korpi@metsa.fi 

Lajitietokeskus - Vihkon yleiset havainnot - http://tun.fi/HR.1747
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Lajitietokeskus - iNaturalist Suomi Finland - http://tun.fi/HR.3211
Kaikki oikeudet pidätetään
Lisätietoja tämän aineiston käytöstä antaa mikko.heikkinen@helsinki.fi

Maalintujen pistelaskennat - http://tun.fi/HR.157
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa aleksi.lehikoinen@helsinki.fi

Rengastus- ja löytörekisteri (TIPU) - http://tun.fi/HR.48
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa jari.valkama@helsinki.fi

eBird (EBIRD) - http://tun.fi/HR.3691
Creative Commons Vapaa
Lisätietoja tämän aineiston käytöstä antaa kari.lahti@helsinki.fi


---

Information about this download and citation instructions: 
http://tun.fi/HBF.53254 

This download is made on 2021-06-08 using the following filters:
Red list status of species: VU – Vulnerable
Time: 1990-01-01/2021-06-08
Loaded to data warehouse, on or before: 2021-06-08
Coordinates: 60.392561 - 60.408755 N 22.446079 - 22.481938 E WGS84 required 
overlap ratio 1.0 
Coordinate accuracy: 100
Link to search: 
https://laji.fi/en/observation/list?redListStatusId=MX.iucnVU&time=1990-01-01%2F2021-06-08&loadedSameOrBefore=2021-06-08&coordinates=60.392561%3A60.408755%3A22.446079%3A22.481938%3AWGS84%3A1.0&coordinateAccuracyMax=100 

This download consists of data from the following information sources and they 
each have their own copyright-license: 

Finnish Insect Database - http://tun.fi/HR.200
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Hatikka.fi observations - http://tun.fi/HR.447
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

LajiGIS: Species monitoring sites - http://tun.fi/HR.3553
Creative Commons Attribution
More information about using this information source can be requested from 
kaisa.junninen@metsa.fi; mira.korpi@metsa.fi 

Lajitietokeskus - Notebook, general observations - http://tun.fi/HR.1747
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Lajitietokeskus - iNaturalist Suomi Finland - http://tun.fi/HR.3211
All rights reserved
More information about using this information source can be requested from 
mikko.heikkinen@helsinki.fi 

Point counts of breeding terrestrial birds - http://tun.fi/HR.157
Creative Commons Attribution
More information about using this information source can be requested from 
aleksi.lehikoinen@helsinki.fi 

Ringing and recovery database of birds (TIPU) - http://tun.fi/HR.48
Creative Commons Attribution
More information about using this information source can be requested from 
jari.valkama@helsinki.fi 

eBird (EBIRD) - http://tun.fi/HR.3691
Creative Commons Zero
More information about using this information source can be requested from 
kari.lahti@helsinki.fi 


---

Information om den här nedladdningen och citat instruktioner: 
http://tun.fi/HBF.53254 

Den här nedladdningen är gjord 8.6.2021 med följande filter:
Artens rödlistekategori: VU – Sårbar
Tid: 1990-01-01/2021-06-08
Laddning till datalager, på eller före: 2021-06-08
Koordinater: 60.392561 - 60.408755 N 22.446079 - 22.481938 E WGS84 Krävs 
överlappningsförhållande 1.0 
Noggrannhet av koordinater: 100
Länk till sökning: 
https://laji.fi/sv/observation/list?redListStatusId=MX.iucnVU&time=1990-01-01%2F2021-06-08&loadedSameOrBefore=2021-06-08&coordinates=60.392561%3A60.408755%3A22.446079%3A22.481938%3AWGS84%3A1.0&coordinateAccuracyMax=100 

Den här nedladdningen består av data från följande informationskällor och de 
har var sin egen upphovsrättslicens: 

Hatikka.fi - http://tun.fi/HR.447
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Hyönteistietokanta - http://tun.fi/HR.200
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

LajiGIS: Lajin seurantakohteet - http://tun.fi/HR.3553
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
kaisa.junninen@metsa.fi; mira.korpi@metsa.fi 

Lajitietokeskus - Skrivbok - http://tun.fi/HR.1747
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Lajitietokeskus - iNaturalist Suomi Finland - http://tun.fi/HR.3211
Alla rättigheter förbehålls
Mer information om den här informationskälla kan beställas från 
mikko.heikkinen@helsinki.fi 

Punkttaxering - http://tun.fi/HR.157
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
aleksi.lehikoinen@helsinki.fi 

Rengastus- ja löytörekisteri (TIPU) - http://tun.fi/HR.48
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
jari.valkama@helsinki.fi 

eBird (EBIRD) - http://tun.fi/HR.3691
Creative Commons
Mer information om den här informationskälla kan beställas från 
kari.lahti@helsinki.fi 


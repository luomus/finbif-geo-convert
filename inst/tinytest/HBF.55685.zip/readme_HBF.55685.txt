Tämän latauksen tietosivu ja viittausohjeet: http://tun.fi/HBF.55685

Lataus on tehty 27.8.2021 seuraavilla rajauksilla:
Kunta: Espoo
Aineisto: Lajitietokeskus - Vihkon yleiset havainnot
Lataus tietovarastoon, päivänä tai ennen: 2021-08-27
Koordinaatit: 60.12164 - 60.251784 N 24.550123 - 24.757177 E WGS84 vaadittu 
päällekkäisyyssuhde 1.0 
Linkki hakuun: 
https://laji.fi/fi/observation/list?finnishMunicipalityId=ML.365&collectionId=HR.1747&loadedSameOrBefore=2021-08-27&coordinates=60.12164%3A60.251784%3A24.550123%3A24.757177%3AWGS84%3A1.0 

Lataus koostuu seuraavista aineistoista joille on määritelty 
käyttöoikeuslisenssi: 

Lajitietokeskus - Mikä laji? -havainnot - http://tun.fi/HR.2832
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Lajitietokeskus - Vihkon yleiset havainnot - http://tun.fi/HR.1747
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi


---

Information about this download and citation instructions: 
http://tun.fi/HBF.55685 

This download is made on 2021-08-27 using the following filters:
Municipality: Espoo
Information source: Lajitietokeskus - Notebook, general observations
Loaded to data warehouse, on or before: 2021-08-27
Coordinates: 60.12164 - 60.251784 N 24.550123 - 24.757177 E WGS84 required 
overlap ratio 1.0 
Link to search: 
https://laji.fi/en/observation/list?finnishMunicipalityId=ML.365&collectionId=HR.1747&loadedSameOrBefore=2021-08-27&coordinates=60.12164%3A60.251784%3A24.550123%3A24.757177%3AWGS84%3A1.0 

This download consists of data from the following information sources and they 
each have their own copyright-license: 

Lajitietokeskus - Notebook, general observations - http://tun.fi/HR.1747
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Lajitietokeskus - Which species? observation - http://tun.fi/HR.2832
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 


---

Information om den här nedladdningen och citat instruktioner: 
http://tun.fi/HBF.55685 

Den här nedladdningen är gjord 27.8.2021 med följande filter:
Kommun: Esbo
Informationskällor: Lajitietokeskus - Skrivbok
Laddning till datalager, på eller före: 2021-08-27
Koordinater: 60.12164 - 60.251784 N 24.550123 - 24.757177 E WGS84 Krävs 
överlappningsförhållande 1.0 
Länk till sökning: 
https://laji.fi/sv/observation/list?finnishMunicipalityId=ML.365&collectionId=HR.1747&loadedSameOrBefore=2021-08-27&coordinates=60.12164%3A60.251784%3A24.550123%3A24.757177%3AWGS84%3A1.0 

Den här nedladdningen består av data från följande informationskällor och de 
har var sin egen upphovsrättslicens: 

Lajitietokeskus - Mikä laji? -havainnot - http://tun.fi/HR.2832
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Lajitietokeskus - Skrivbok - http://tun.fi/HR.1747
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi


Lataus on tehty 6.9.2021 seuraavilla rajauksilla:
Aika: 2021-01-01/
Poissuljettu aineisto: Lajitietokeskus - Vihkon yleiset havainnot, 
Lajitietokeskus - Sieniatlas, SYKE - Kimalaisseuranta, Luomus - 
Talvilintulaskenta, Lajitietokeskus - Vieraslajien torjunta, Luomus - 
Maalintujen pistelaskennat, SYKE - SYKE - Maatalousympäristön 
päiväperhosseuranta, Valtakunnallinen päiväperhosseuranta (NAFI), 
Luonnontieteellisen keskusmuseon Luomuksen kokoelmat (Luomus), Lajitietokeskus 
- Liito-Orava-Life (LOLIFE), Kiiltomadot, Luonto-Liiton kevätseuranta, Luomus - 
Maalintujen linjalaskennat, Kokoelmakilpailu, Lajitietokeskus - 
Viekas-projektin vieraslajihavainnot, Luomus - I Lintuatlas, Lajitietokeskus - 
Lukiolaiset lepakkotutkijoina, Lajitietokeskus - Lajien havainnointi 
maitotiloilla 
Lataus tietovarastoon, päivänä tai ennen: 2021-09-06
Linkki hakuun: 
https://laji.fi/fi/observation/list?time=2021-01-01%2F&collectionIdNot=HR.1747%2CHR.2129%2CHR.3911%2CHR.39%2CHR.2049%2CHR.157%2CHR.3431%2CHR.175%2CHR.128%2CHR.2951%2CHR.3531%2CHR.206%2CHR.61%2CHR.2629%2CHR.3051%2CHR.57%2CHR.2991%2CHR.3071&loadedSameOrBefore=2021-09-06 

Saadaksesi tämän latauksen tiedot olet hyväksynyt aineistoja koskevat ehdot. 
Ehdot ovat luettavissa aineistopyyntöpalvelusta, josta latasit nämä tiedostot. 
Et saa jakaa tiedostoja eteenpäin henkilöille, joita ei oltu määritelty 
aineistopyyntöä tehtäessä. 

---

This download is made on 2021-09-06 using the following filters:
Time: 2021-01-01/
Excluded information source: Lajitietokeskus - Notebook, general observations, 
Lajitietokeskus - Fungal atlas, SYKE - Bumblebee census, Luomus - Winter Bird 
Census, Lajitietokeskus - Invasive alien species control, Luomus - Point counts 
of breeding terrestrial birds, SYKE - SYKE - Butterflies in Finnish 
agricultural landscapes, National Finnish butterfly monitoring scheme (NAFI), 
Collections of the Finnish Museum of Natural History Luomus (Luomus), 
Lajitietokeskus - Flying-Squirrel-Life (LOLIFE), Glow worm, The Finnish Nature 
League's Spring monitoring, Luomus - Line transect censuses of breeding birds, 
Collection contest, Lajitietokeskus - Viekas project invasive species 
observations, Luomus - First Finnish Breeding Bird Atlas, Lajitietokeskus - 
Gymnasium students as bat researchers, Lajitietokeskus - Observing species on 
milk farms 
Loaded to data warehouse, on or before: 2021-09-06
Link to search: 
https://laji.fi/en/observation/list?time=2021-01-01%2F&collectionIdNot=HR.1747%2CHR.2129%2CHR.3911%2CHR.39%2CHR.2049%2CHR.157%2CHR.3431%2CHR.175%2CHR.128%2CHR.2951%2CHR.3531%2CHR.206%2CHR.61%2CHR.2629%2CHR.3051%2CHR.57%2CHR.2991%2CHR.3071&loadedSameOrBefore=2021-09-06 

To get this data you have accepted the terms and conditions for the material. 
The terms and conditions are available for review from the page where you 
downloaded these files. You may not share these files to persons who had not 
been specified in the data request. 

---

Den här nedladdningen är gjord 6.9.2021 med följande filter:
Tid: 2021-01-01/
Utesluten informationskälla: Lajitietokeskus - Skrivbok, Lajitietokeskus - 
Sieniatlas, SYKE - Kimalaisseuranta, Luomus - Vinterfågeltaxeringar, 
Lajitietokeskus - Vieraslajien torjunta, Luomus - Punkttaxering, SYKE - SYKE - 
Maatalousympäristön päiväperhosseuranta, Valtakunnallinen päiväperhosseuranta 
(NAFI), Samlingar av Naturhistoriska centralmuseet Luomus (Luomus), 
Lajitietokeskus - Flygekorre-Life (LOLIFE), Kiiltomadot, Luonto-Liittos och 
Natur och Miljös Följ med våren, Luomus - Linjetaxering, Insamlingstävling, 
Lajitietokeskus - Viekas-projektin vieraslajihavainnot, Luomus - I Lintuatlas, 
Lajitietokeskus - gymnasieelever som fladderforskare, Lajitietokeskus - Lajien 
havainnointi maitotiloilla 
Laddning till datalager, på eller före: 2021-09-06
Länk till sökning: 
https://laji.fi/sv/observation/list?time=2021-01-01%2F&collectionIdNot=HR.1747%2CHR.2129%2CHR.3911%2CHR.39%2CHR.2049%2CHR.157%2CHR.3431%2CHR.175%2CHR.128%2CHR.2951%2CHR.3531%2CHR.206%2CHR.61%2CHR.2629%2CHR.3051%2CHR.57%2CHR.2991%2CHR.3071&loadedSameOrBefore=2021-09-06 

Du har accepterat villkoren för materialet, för att få denna data. Villkoren 
finns tillgängliga för granskning från den sidan där du hämtade filerna. Du får 
inte dela dessa filer till personer som inte hade angetts i begäran om data. 

